# Script di Installazione Agenti TTR-SUITE

## Panoramica
Questo script installa automaticamente i file DLL degli agenti TTR-SUITE nella directory di installazione di TTR-SUITE.

## Requisiti
- TTR-SUITE deve essere installato in `C:\TTR-SUITE\`
- File agenti in formato ZIP
- Windows con supporto PowerShell (per estrazione ZIP)

## Come Utilizzare

### Installazione Semplice (Consigliata)
1. Posiziona il file ZIP degli agenti nella stessa directory di `install-agents.bat`
2. Fai doppio clic su `install-agents.bat`
3. Lo script rileverà automaticamente il file ZIP
4. Segui le istruzioni a schermo

**IMPORTANTE**: Lo script deve trovare UN SOLO file ZIP nella directory corrente.

## Cosa Fa lo Script

1. **Verifica**: Controlla se TTR-SUITE è installato in `C:\TTR-SUITE\`
2. **Pulizia**: Rimuove completamente la directory `C:\TTR-SUITE\AppData\AgentCodes\` esistente
3. **Creazione**: Crea nuovamente la directory `C:\TTR-SUITE\AppData\AgentCodes\`
4. **Copia**: Copia il file ZIP nella directory di destinazione
5. **Estrazione**: Estrae il file ZIP direttamente nella directory di destinazione
6. **Pulizia**: Rimuove il file ZIP dopo l'estrazione

## Gestione Errori
Lo script include gestione degli errori per:
- Installazione TTR-SUITE mancante
- File ZIP non trovato
- Errori di estrazione
- Errori di copia
- Problemi di permessi

## Riepilogo Installazione
Dopo l'installazione, lo script fornisce:
- Numero di file DLL installati
- Conferma dell'installazione completata

## Risoluzione Problemi

### Problemi Comuni
1. **"TTR-SUITE non trovato"**: Assicurati che TTR-SUITE sia installato in `C:\TTR-SUITE\`
2. **"Nessun file ZIP trovato"**: Posiziona il file ZIP degli agenti nella stessa directory dello script
3. **"Permesso negato"**: Esegui lo script come Amministratore
4. **"Impossibile estrarre ZIP"**: Assicurati che il file ZIP non sia corrotto

### Installazione Manuale
Se lo script fallisce, puoi copiare manualmente i file DLL in:
```
C:\TTR-SUITE\AppData\AgentCodes\
```

## Note
- Lo script pulisce completamente la directory di destinazione prima dell'installazione
- Riavvia TTR-SUITE dopo l'installazione per caricare i nuovi agenti
- Il file ZIP deve essere nella stessa directory dello script