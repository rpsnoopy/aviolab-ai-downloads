# TTR-SUITE Agent Installation Script

## Overview
This script automatically installs TTR-SUITE agent DLL files to your TTR-SUITE installation directory.

## Requirements
- TTR-SUITE must be installed at `C:\TTR-SUITE\`
- Agent files in ZIP format
- Windows with PowerShell support (for ZIP extraction)

## How to Use

### Simple Installation (Recommended)
1. Place the agent ZIP file in the same directory as `install-agents.bat`
2. Double-click `install-agents.bat`
3. The script will automatically detect the ZIP file
4. Follow the on-screen prompts

**IMPORTANT**: The script must find EXACTLY ONE ZIP file in the current directory.

## What the Script Does

1. **Verification**: Checks if TTR-SUITE is installed at `C:\TTR-SUITE\`
2. **Cleanup**: Completely removes the existing `C:\TTR-SUITE\AppData\AgentCodes\` directory
3. **Creation**: Creates a new `C:\TTR-SUITE\AppData\AgentCodes\` directory
4. **Copy**: Copies the ZIP file to the destination directory
5. **Extraction**: Extracts the ZIP file directly in the destination directory
6. **Cleanup**: Removes the ZIP file after extraction

## Error Handling
The script includes error handling for:
- Missing TTR-SUITE installation
- ZIP file not found
- Extraction failures
- Copy failures
- Permission issues

## Installation Summary
After installation, the script provides:
- Number of DLL files installed
- Confirmation of completed installation

## Troubleshooting

### Common Issues
1. **"TTR-SUITE not found"**: Ensure TTR-SUITE is installed at `C:\TTR-SUITE\`
2. **"No ZIP file found"**: Place the agent ZIP file in the same directory as the script
3. **"Permission denied"**: Run the script as Administrator
4. **"Failed to extract ZIP"**: Ensure the ZIP file is not corrupted

### Manual Installation
If the script fails, you can manually copy DLL files to:
```
C:\TTR-SUITE\AppData\AgentCodes\
```

## Notes
- The script completely cleans the destination directory before installation
- Restart TTR-SUITE after installation to load new agents
- The ZIP file must be in the same directory as the script